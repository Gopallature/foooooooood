package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IDishDao;
import com.app.dao.IRestoDao;
import com.app.dao.RestoDaoImpl;
import com.app.pojos.Customer;
import com.app.pojos.Dish;
import com.app.pojos.DishCategory;
import com.app.pojos.Restaurant;

@Service
@Transactional
public class ServiceImp implements Iservice {
	@Autowired
	private IRestoDao dao;
	@Autowired
	private IDishDao DaoDish;

	@Override
	public Customer registerCust(Customer c) {
		Customer cc=dao.registerCust(c);
		return cc ;
	}

	@Override
	public Restaurant registerResto(Restaurant r) {
		return dao.registerResto(r);
	}

	@Override
	public Customer loginCust(String name, String pass) {
		
		return dao.loginCust(name, pass);
	}

	@Override
	public List<Dish> Dishlist() {
		return dao.Dishlist();
	}

	@Override
	public Restaurant loginRest(String name, String pass) {
		
		return dao.loginRest(name, pass);
	}

	@Override
	public String registerDish(Restaurant r, Dish d) {
		
		return DaoDish.registerDish(r, d);
	}

	@Override
	public List<Dish> showRestoDish(Restaurant r) {
		
		return DaoDish.ShowRestoDish(r);
	}

	@Override
	public Dish getDishDetails(int dishId) {
		
		return DaoDish.getDishDetails(dishId);
	}

	@Override
	public String deleteDish(int dishId) {
		
		return DaoDish.deleteDish(dishId);
	}

	@Override
	public String updateDish(Dish d) {
		
		return DaoDish.updateDish(d);
	}

	@Override
	public List<Restaurant> showAllResto() {
		
		return dao.showAllResto();
	}

	@Override
	public List<Dish> showByCat(DishCategory category) {
		
		return DaoDish.showByCat(category);
	}

	@Override
	public Dish addDishToCart(int dishId) {
		
		return DaoDish.AddDishToCart(dishId);
	}
	

}
