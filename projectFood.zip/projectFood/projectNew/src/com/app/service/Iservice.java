package com.app.service;

import java.util.List;

import com.app.pojos.Customer;
import com.app.pojos.Dish;
import com.app.pojos.DishCategory;
import com.app.pojos.Restaurant;

public interface Iservice {
	public Customer registerCust(Customer c);
	public Restaurant registerResto(Restaurant c);
	public Customer loginCust(String name ,String pass);
	public List<Dish> Dishlist();
	public Restaurant loginRest(String name ,String pass);
	public String registerDish(Restaurant r ,Dish d);
	public List<Dish> showRestoDish(Restaurant r);
	public Dish getDishDetails(int dishId);
	public String deleteDish(int dishId);
	public String updateDish(Dish d);
	public List<Restaurant> showAllResto();
	public List<Dish> showByCat(DishCategory category);
	public Dish addDishToCart(int dishId);

}
