package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;

import com.app.pojos.Dish;
import com.app.pojos.DishCategory;
import com.app.pojos.Restaurant;

@Repository
public class DishdaoImpl implements IDishDao {
	@Autowired
	private SessionFactory sf;
	 private static int id; 

	public DishdaoImpl() {
		super();
		System.out.println("in dao of Dishdao");
	}

	@Override
	public String registerDish(Restaurant r, Dish a) {
		r.addDish(a);
		sf.getCurrentSession().update(r);
		
		return "dish added successfully with id:"+a.getDishId() ;
	}

	@Override
	public List<Dish> ShowRestoDish(Restaurant r) {
		Restaurant res= new Restaurant(r.getRestId());
		String jpql="select d from Dish d where d.rest=:resto";
		
		return sf.getCurrentSession().createQuery(jpql, Dish.class).setParameter("resto", res).getResultList();
	}

	@Override
	public Dish getDishDetails(int dishId) {
		String jpql="select d from Dish d where d.dishId=:id";
		return sf.getCurrentSession().createQuery(jpql, Dish.class).setParameter("id", dishId).getSingleResult();
	}

	@Override
	public String deleteDish(int dishId) {
		Dish d=sf.getCurrentSession().get(Dish.class,dishId);
		Restaurant res=d.getRest();
		if(d!=null) {
			
		res.removeDish(d);
		sf.getCurrentSession().update(res);
		
			return "Dish Deleted of Id"+dishId;
		}
		return "deletion failed";
		
	}

	@Override
	public String updateDish(Dish d) {
		int dishId=d.getDishId();
		Dish dbDish=sf.getCurrentSession().get(Dish.class,dishId);
		Restaurant res=dbDish.getRest();
		res.removeDish(dbDish);
		{
		sf.getCurrentSession().update(res);
		}
			upDish(  d,res);
		
		return "Dish updated successfully";
	}
	
	public void upDish(Dish d,Restaurant res) {
		
		Dish dish= new Dish(d.getDishName(),d.getPrice(),d.isAvailablity(),d.getCategory(),d.getDescript());
		res.addDish(dish);
		sf.getCurrentSession().update(res);
		
	}

	@Override
	public List<Dish> showByCat(DishCategory category) {
		String jpql="select d from Dish d where d.category=:cat";
		return sf.getCurrentSession().createQuery(jpql, Dish.class).setParameter("cat", category).getResultList();
		
	}

	@Override
	public Dish AddDishToCart(int dishId) {
		String jpql="select d from Dish d where d.dishId=:id";
		return sf.getCurrentSession().createQuery(jpql, Dish.class).setParameter("id", dishId).getSingleResult();
	}

	
	
	
	
	

}
