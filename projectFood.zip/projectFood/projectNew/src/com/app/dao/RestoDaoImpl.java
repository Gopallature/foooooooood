package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.app.pojos.Customer;
import com.app.pojos.Dish;
import com.app.pojos.Restaurant;
@Repository
public class RestoDaoImpl implements IRestoDao {
@Autowired
 private SessionFactory sf;
 
	public RestoDaoImpl() {
		super();
		System.out.println("in foodDao constructor");
		
	}

	@Override
	public Customer registerCust(Customer c) {
		int id=(int) sf.getCurrentSession().save(c);
		if(id != 0) {
			
		return c;
		}
		else {
			return null;
		}	
		
	}

	@Override
	public Restaurant registerResto(Restaurant r) {
		int id=(int)sf.getCurrentSession().save(r);
		if(id != 0) {
			
			return r;
			}
			else {
				return null;
			}	
			
	
	}

	@Override
	public Customer loginCust(String name, String password) {
		String jpql="select c from Customer c where c.custName=:nm and c.custPass=:pass";
		return sf.getCurrentSession().createQuery(jpql,Customer.class).setParameter("nm", name).setParameter("pass", password).getSingleResult();
	
	}

	@Override
	public List<Dish> Dishlist() {
		String jpql= "select d from Dish d";
		return  sf.getCurrentSession().createQuery(jpql, Dish.class).getResultList();
	}

	@Override
	public Restaurant loginRest(String name, String password) {
		String jpql="select r from Restaurant r where r.restName=:nm and r.restPass=:pass";
		return sf.getCurrentSession().createQuery(jpql,Restaurant.class).setParameter("nm", name).setParameter("pass", password).getSingleResult();
		
	}

	@Override
	public List<Restaurant> showAllResto() {
		String jpql="select r from Restaurant r";
		return sf.getCurrentSession().createQuery(jpql,Restaurant.class).getResultList();
		
	}

	
	

}
