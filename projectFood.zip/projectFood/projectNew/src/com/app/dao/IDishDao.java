package com.app.dao;

import java.util.List;

import com.app.pojos.Dish;
import com.app.pojos.DishCategory;
import com.app.pojos.Restaurant;

public interface IDishDao {

	String registerDish(Restaurant r,Dish a);
	//String closeAccount(int acctId);
	List<Dish> ShowRestoDish(Restaurant r);
	Dish getDishDetails(int dishId);
	String deleteDish(int dishId);
	String updateDish(Dish d);
	
	List<Dish> showByCat(DishCategory category);
	Dish AddDishToCart(int dishId);
}
