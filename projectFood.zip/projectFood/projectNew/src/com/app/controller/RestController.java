package com.app.controller;

import java.util.List;

import javax.persistence.NoResultException;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Customer;
import com.app.pojos.Dish;
import com.app.pojos.DishCategory;
import com.app.pojos.Restaurant;
import com.app.service.Iservice;
import com.app.service.ServiceImp;

@Controller
@RequestMapping("/Resto")
public class RestController {
	@Autowired
	 private Iservice s;
	@Autowired
	 private HttpSession hs;

	public RestController() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("in restro controller const");
	}
	@GetMapping("/Rregister")
	public String registerResto(Restaurant r)
	{
		
		return "/Resto/Rregister";
	}
	
	
	@PostMapping("/Rregister")
	public String registerRestro(@RequestParam String name,@RequestParam  String password,
			@RequestParam String adress) {
	Restaurant r= s.registerResto(new Restaurant(name,password,adress));
		return "redirect:/Resto/Rlogin";
	} 
	
	
	@GetMapping("/Rlogin")
	public String loginRest() {
		return "/Resto/Rlogin";
	}


	@PostMapping("/Rlogin")
	public String loginRest(@RequestParam String name,@RequestParam String password , 
			Model map)
	{
		Restaurant r=null;
		try {
			r= s.loginRest(name, password);	
		} catch (NoResultException e) {
			map.addAttribute("status", "login failed , try again ");
			return "/Resto/Rlogin";
		}
		
	
		map.addAttribute("status", "login successfull");
		hs.setAttribute("Restaurant_r", r);
		return "redirect:/Resto/ShowDish";
	
	
	}
	
	@GetMapping("/ShowDish")
	public String ShowRestoDish(){
		Restaurant r=(Restaurant)hs.getAttribute("Restaurant_r");
		List<Dish> Dishes=s.showRestoDish(r);
		hs.setAttribute("Resto_Dishes", Dishes);
		return "/Resto/ShowDish";
	}
	
	
	
	/*@PostMapping("/ShowDish")
	public String ShowRestoDish(Dish d) {
		
	 return "/Resto/DishRegister";	
	}*/

	@GetMapping("/DishRegister")
	public String registerDish(HttpSession hs)
	{
		hs.setAttribute("Category",DishCategory.values());
		System.out.println("in resturant register dish");
		
		return "/Resto/DishRegister";
	}
	@PostMapping("/DishRegister")
	public String registerDish(@RequestParam String dishName,@RequestParam double price,@RequestParam boolean availablity,@RequestParam DishCategory category,
			@RequestParam String descript,Model map)
	{
		Dish d=new Dish(dishName,price,availablity,category,descript); 
		Restaurant r=(Restaurant)hs.getAttribute("Restaurant_r");
		s.registerDish(r, d);
		
		return "redirect:/Resto/ShowDish";
	}
	@GetMapping("/Update")
	public String updateDish(@RequestParam int dishId,Model map)
	{
		map.addAttribute("cat",DishCategory.values());
		Dish d= s.getDishDetails(dishId);
		if(d!=null) {
			map.addAttribute( d);
		return "/Resto/Update";
		}
		else
		{
			map.addAttribute("Status", "updation failed");
			return "/Resto/ShowDish";
		}
	}
	
	@PostMapping("/Update")
	public String UpdateDish( Dish d,Model map)
	{
		hs.getAttribute("Category");
		map.addAttribute("Status_Update", s.updateDish(d));
		return"redirect:/Resto/ShowDish";
	}
	@GetMapping("/Delete")
	public String deleteDish(@RequestParam int dishId ,Model map)
	{
	String dlt=s.deleteDish(dishId);
	map.addAttribute("delete_status", dlt);
		return "redirect:/Resto/ShowDish";
		
	}
}
