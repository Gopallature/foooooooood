
package com.app.pojos;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "Customer")
public class Customer {
	private int custId;
	//@NotEmpty(message = "Name must be supplied")
	private String custName;
	//@NotEmpty(message = "password must be supplied")
	//@Pattern(regexp="((?=.*\\d)(?=.*[a-z])(?=.*[#@$*]).{5,20})",message="Invalid password")
	private String custPass;
	//@NotEmpty(message = "address must be supplied")
	private String custAddress;
	//@NotEmpty(message = "mobile numbre must be supplied")
	private String custMobile;
	//@Email(message="Invalid Email Format")
	private String custEmail;
	public Customer() {
		super();
		System.out.println("in constructor of customer");
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getCustId() {
		return custId;
	}
	public Customer(String custName, String custPass, String custAddress, String custMobile, String custEmail) {
		super();
		this.custName = custName;
		this.custPass = custPass;
		this.custAddress = custAddress;
		this.custMobile = custMobile;
		this.custEmail = custEmail;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}
	@Column(name="CustomerName",length=20)
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	@Column(name="CustomerPassword",length=10)
	public String getCustPass() {
		return custPass;
	}
	public void setCustPass(String custPass) {
		this.custPass = custPass;
	}
	@Column(name="CustomerAddress",length=50)
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	@Column(name="CustomerMobile",length=12)
	public String getCustMobile() {
		return custMobile;
	}
	public void setCustMobile(String custMobile) {
		this.custMobile = custMobile;
	}

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

}
