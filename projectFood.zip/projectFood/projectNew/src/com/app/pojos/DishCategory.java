package com.app.pojos;

public enum DishCategory {
	SOUTH_INDIAN,NORTH_INDIAN,BREAK_FAST,LUNCH,CHINESE,DESSERTS,DINNER,DRINKS

}
