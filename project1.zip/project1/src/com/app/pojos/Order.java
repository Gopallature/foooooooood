package com.app.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Order")
public class Order {
  private int orderId;
  private int CustomerId;
  private int  DishId;
  private int restId;
  private int Quantity;
  private double bill;
public Order(int customerId, int dishId, int restId, int quantity, double bill) {
	super();
	CustomerId = customerId;
	DishId = dishId;
	this.restId = restId;
	Quantity = quantity;
	this.bill = bill;
}
public Order() {
	super();
	// TODO Auto-generated constructor stub
}
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY.AUTO)
public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
public int getCustomerId() {
	return CustomerId;
}
public void setCustomerId(int customerId) {
	CustomerId = customerId;
}
public int getDishId() {
	return DishId;
}
public void setDishId(int dishId) {
	DishId = dishId;
}
public int getRestId() {
	return restId;
}
public void setRestId(int restId) {
	this.restId = restId;
}
public int getQuantity() {
	return Quantity;
}
public void setQuantity(int quantity) {
	Quantity = quantity;
}
public double getBill() {
	return bill;
}
public void setBill(double bill) {
	this.bill = bill;
}

}
