package com.app.pojos;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "Dish")
public class Dish {
	
	private int dishId;
	@NotEmpty(message = "Name must be supplied")
	private String dishName;
	//@NotEmpty(message = "Price must be supplied")
	private double price;
	//@NotEmpty(message = "Availability must be supplied")
	private boolean Availablity;
	//@NotEmpty(message = "Category must be supplied")
	private DishCategory category;
	//private byte[] dishimage;
	private String descript ;
	
	private Restaurant rest;
	
	public Dish() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Dish(String dishName, double price, boolean availablity, DishCategory category,
			String descript ) {
		super();
		this.dishName = dishName;
		this.price = price;
		Availablity = availablity;
		this.category = category;
		//this.dishimage = dishimage;
		this.descript = descript ;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Dish_Id")
	public int getDishId() {
		return dishId;
	}
	public void setDishId(int dishId) {
		this.dishId = dishId;
	}
	public String getDishName() {
		return dishName;
	}
	public void setDishName(String dishName) {
		this.dishName = dishName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public boolean isAvailablity() {
		return Availablity;
	}
	public void setAvailablity(boolean availablity) {
		Availablity = availablity;
	}
	
	@Enumerated(EnumType.STRING)
	@Column(name="Dish_category")
	public DishCategory getCategory() {
		return category;
	}
	public void setCategory(DishCategory category) {
		this.category = category;
	}
	/*public byte[] getDishimage() {
		return dishimage;
	}
	public void setDishimage(byte[] dishimage) {
		this.dishimage = dishimage;
	}*/
	public String getDescript  () {
		return descript ;
	}
	public void setDescript (String descript ) {
		this.descript  = descript ;
	}
	@ManyToOne
	@JoinColumn(name="rest_id")
	public Restaurant getRest() {
		return rest;
	}
	
	public void setRest(Restaurant rest) {
		this.rest = rest;
	}
	@Override
	public boolean equals(Object o) {
		if( o instanceof Dish) {
			Dish d=(Dish)o;
			return( d.dishId)==(this.dishId);
		}
		return false;
	}
	@Override
	public String toString() {
		return "Dish [dishId=" + dishId + ", dishName=" + dishName + ", price=" + price + ", Availablity=" + Availablity
				+ ", category=" + category + ", descript =" + descript  + "]";
	}
	
	
	
	

}
