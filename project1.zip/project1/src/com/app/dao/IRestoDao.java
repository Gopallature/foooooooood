package com.app.dao;

import java.util.List;

import com.app.pojos.Customer;
import com.app.pojos.Dish;
import com.app.pojos.Restaurant;



public interface IRestoDao {

	Customer registerCust(Customer c);
	Restaurant registerResto(Restaurant r);
	Customer loginCust(String name,String password );
	List<Dish> Dishlist();
	Restaurant loginRest(String name,String password );
	List<Restaurant> showAllResto();
	
}
