package com.app.controller;


import java.lang.ProcessBuilder.Redirect;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Customer;
import com.app.pojos.Dish;
import com.app.pojos.DishCategory;
import com.app.pojos.Restaurant;
import com.app.service.Iservice;
import com.app.service.ServiceImp;

@Controller
@RequestMapping("/Customer")
public class CustController {
	@Autowired
	private Iservice s;
	private   static List<Dish> dishlist=new ArrayList<Dish>();
	
	
	

	public CustController() {
		super();
		System.out.println("in customer controller const");
		// TODO Auto-generated constructor stub
	}

@GetMapping("/register")
public String registerCust() {
	
	return "/Customer/register";
}
@PostMapping("/register")
public String registerCust(@RequestParam String name,@RequestParam String password,@RequestParam String email
		,@RequestParam String mobile,@RequestParam String adress ) {
	Customer c= s.registerCust(new Customer(name,password,email,mobile ,adress));
	if(c!=null) {
		System.out.println("customer registerd");
	}
	else {
		System.out.println("error in registration");
	}
	return "redirect:/Customer/Clogin";
	
}
@GetMapping("/Clogin")
public String loginCust() {
	
	return "/Customer/Clogin";
}


@PostMapping("/Clogin")
public String loginCust(@RequestParam String name,@RequestParam String password ,HttpSession hs, 
		Model map)
{
	dishlist.removeAll(dishlist);
	Customer c= null;
	try {
		 c= s.loginCust(name, password);	
		} catch (NoResultException e) {
			map.addAttribute("status", "login failed , try again ");
			return"/Customer/Clogin";
		
	}
	
		map.addAttribute("status", "login successfull welcome "+c.getCustName());
		hs.setAttribute("Customer", c);
	
	return "redirect:/Customer/ShowResto";

}
@GetMapping("/Dishlist")
public String Dishlist( Model map)
{
	
	map.addAttribute("Dish_list", s.Dishlist());
	System.out.println("in cust redirect get method");
	
return "/Customer/Dishlist";
}

@GetMapping("/ShowResto")
public String showAllResto( Model map){
	map.addAttribute("All_Resto", s.showAllResto());
	 map.addAttribute("All_category", DishCategory.values());
	return "/Customer/ShowResto";
	
}
@PostMapping("/ShowResto")
public String showAllResto() {
	
	return "redirect:/Customer/SearchByResto";
	
}
@GetMapping("/SearchByResto")
public String searchByResto(@RequestParam int restId,Model map,HttpSession hs)
{
	
	List<Dish> rest= s.showRestoDish(new Restaurant(restId));
	
		hs.setAttribute("Resto_dish",rest);
	return "/Customer/SearchByResto";
	}
	

@PostMapping("/SearchByResto")
public String searchByResto( Dish d,Model map)
{
	map.addAttribute("Status_Update", s.updateDish(d));
	return"redirect:/Resto/ShowDish";
}

@PostMapping("/SearchBycatPost")
public String searchByCatPost(@RequestParam DishCategory  category,HttpSession hs,Model map){
	hs.setAttribute("Show_By_Cat",s.showByCat(category));
	hs.setAttribute("searchby_cat",category );
	System.out.println("in show by category custcontroller");
	
	return  "redirect:/Customer/SearchByCat";
	
}

@GetMapping("/SearchByCat")
public String searchByCat() {
	return"/Customer/SearchByCat";
}

@PostMapping("/SearchByCat")
public String searchByCat(Model map) 
{
 return"redirect:/Customer/Cart";	
}

@GetMapping("/Cart")
public String ShowCart(@RequestParam int dishId,HttpSession hs)
{
	 
	dishlist.add(s.addDishToCart(dishId));
	hs.setAttribute("Dish_addTO_cart", dishlist);
	

return "/Customer/Cart";
}

@PostMapping("/Cart")
public String ShowCart()
{
	return"redirect:/Customer/Cart";
}
@GetMapping("/RemoveFromCart")
public String RemoveFromCart(@RequestParam int dishId,HttpSession hs)
{
	 List<Dish> dishlist=(List<Dish>)hs.getAttribute("Dish_addTO_cart");
	Dish d= s.getDishDetails(dishId);
	int index=dishlist.indexOf(d);
	Dish dish=dishlist.remove(index);
	System.out.println("status:"+dish);
	return"/Customer/Cart";
}
@PostMapping("/RemoveFromCart")
public String RemoveFromCart() {
	
	return"redirect:/Customer/Cart";
}

}
