package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="resto")
public class Restaurant {
	private int restId;
	@NotEmpty(message = "Name must be supplied")
	private String restName;
	@NotEmpty(message = "Password must be supplied")
	private String restPass;
	@NotEmpty(message = "addr must be supplied")
	private String restAddress;
	private List<Dish> dishes=new ArrayList<>();
	
	
	public Restaurant(int restId) {
		super();
		this.restId = restId;
	}

	public Restaurant() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Restaurant(String restName, String restPass, String restAddress) {
		super();
		this.restName = restName;
		this.restPass = restPass;
		this.restAddress = restAddress;
		
	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY.AUTO)
	public int getRestId() {
		return restId;
	}
	public void setRestId(int restId) {
		this.restId = restId;
	}
	@Column(unique=true)
	public String getRestName() {
		return restName;
	}
	public void setRestName(String restName) {
		this.restName = restName;
	}
	public String getRestPass() {
		return restPass;
	}
	public void setRestPass(String restPass) {
		this.restPass = restPass;
	}
	public String getRestAddress() {
		return restAddress;
	}
	public void setRestAddress(String restAddress) {
		this.restAddress = restAddress;
	}
	@OneToMany(fetch = FetchType.EAGER,mappedBy="rest",cascade=CascadeType.ALL)
	public List<Dish> getDishes() {
		return dishes;
	}
	public void setDishes(List<Dish> dishes) {
		this.dishes = dishes;
	}
	
	public void addDish(Dish a)
	{
		dishes.add(a);
		a.setRest(this);
	}

	public void removeDish(Dish a)
	{
		dishes.remove(a);
		a.setRest(null);
	}
}
